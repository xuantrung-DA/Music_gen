import streamlit as st
from audiocraft.models import MusicGen
import soundfile as sf
import os
import numpy as np
import time

st.set_page_config(
    page_title="MusicGen Studio Pro", 
    page_icon="🎵", 
    layout="wide",
    initial_sidebar_state="collapsed"
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * {
        font-family: 'Inter', sans-serif;
    }
    
    .main-container {
        padding: 2rem;
    }
    
    .glass-card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 2rem;
        margin: 1rem 0;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }
    
    .glass-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    }
    
    .hero-title {
        font-size: 3.5rem;
        font-weight: 700;
        background: linear-gradient(45deg, #ffffff, #f0f8ff);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }
    
    .subtitle {
        font-size: 1.2rem;
        color: rgba(255, 255, 255, 0.8);
        text-align: center;
        margin-bottom: 2rem;
        font-weight: 300;
    }
    
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin: 2rem 0;
    }
    
    .feature-card {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 15px;
        padding: 1.5rem;
        text-align: center;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.3s ease;
    }
    
    .feature-card:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: scale(1.05);
    }
    
    .feature-icon {
        font-size: 2.5rem;
        margin-bottom: 1rem;
    }
    
    .feature-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: white;
        margin-bottom: 0.5rem;
    }
    
    .feature-desc {
        font-size: 0.9rem;
        color: rgba(255, 255, 255, 0.7);
        line-height: 1.4;
    }
    
    .stTextInput > div > div > input {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        color: white;
        font-size: 1.1rem;
        padding: 0.8rem 1rem;
        backdrop-filter: blur(5px);
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
    }
    
    .stButton > button {
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        border: none;
        border-radius: 25px;
        padding: 0.8rem 2rem;
        font-size: 1.1rem;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        width: 100%;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    }
    
    .stButton > button:active {
        transform: translateY(0);
    }
    
    .generation-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 1rem;
        margin: 1rem 0;
    }
    
    .stat-card {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .stat-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #667eea;
        margin-bottom: 0.2rem;
    }
    
    .stat-label {
        font-size: 0.8rem;
        color: rgba(255, 255, 255, 0.7);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .pulse-animation {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    
    .loading-spinner {
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top: 4px solid #667eea;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: 0 auto;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .success-message {
        background: linear-gradient(45deg, #4CAF50, #45a049);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        text-align: center;
        font-weight: 600;
        margin: 1rem 0;
        animation: slideIn 0.5s ease-out;
    }
    
    @keyframes slideIn {
        from { transform: translateY(-20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
    
    .audio-player-container {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .download-section {
        background: linear-gradient(45deg, rgba(102, 126, 234, 0.2), rgba(118, 75, 162, 0.2));
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.2);
        text-align: center;
    }
    
    .prompt-examples {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 15px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .example-tag {
        display: inline-block;
        background: rgba(102, 126, 234, 0.3);
        color: white;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.8rem;
        margin: 0.2rem;
        cursor: pointer;
        transition: all 0.3s ease;
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .example-tag:hover {
        background: rgba(102, 126, 234, 0.5);
        transform: scale(1.05);
    }
    
    .stSelectbox > div > div > select {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        color: white;
        backdrop-filter: blur(5px);
    }
    
    .stSlider > div > div > div {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
    }
    
    .stAlert > div {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(5px);
    }
    
    /* Hide Streamlit branding */
    .css-1d391kg {
        display: none;
    }
    
    .css-1y4p8pa {
        max-width: 100%;
    }
    
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    
    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: rgba(102, 126, 234, 0.5);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: rgba(102, 126, 234, 0.7);
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-container">', unsafe_allow_html=True)

st.markdown("""
<div class="glass-card">
    <h1 class="hero-title">🎵 9.5 MusicGen Studio</h1>
    <p class="subtitle">
        Create professional-quality music with AI-powered generation using Meta's advanced MusicGen model
    </p>
</div>
""", unsafe_allow_html=True)

st.markdown("""
<div class="glass-card">
    <div class="feature-grid">
        <div class="feature-card">
            <div class="feature-icon">🎼</div>
            <div class="feature-title">AI Music Generation</div>
            <div class="feature-desc">Create unique tracks from text prompts using advanced AI</div>
        </div>
        <div class="feature-card">
            <div class="feature-icon">🎚️</div>
            <div class="feature-title">Professional Quality</div>
            <div class="feature-desc">High-fidelity audio output at 32kHz sample rate</div>
        </div>
        <div class="feature-card">
            <div class="feature-icon">⚡</div>
            <div class="feature-title">Fast Generation</div>
            <div class="feature-desc">Quick processing with real-time progress updates</div>
        </div>
        <div class="feature-card">
            <div class="feature-icon">💾</div>
            <div class="feature-title">Easy Export</div>
            <div class="feature-desc">Download your creations as high-quality WAV files</div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner=False)
def load_model():
    model = MusicGen.get_pretrained('medium')
    model.set_generation_params(duration=15)
    return model
if 'duration' not in st.session_state:
    st.session_state['duration'] = 15
if 'audio' not in st.session_state:
    st.session_state['audio'] = None
if 'prompt' not in st.session_state:
    st.session_state['prompt'] = ""
if 'generation_time' not in st.session_state:
    st.session_state['generation_time'] = 0

if 'model' not in st.session_state:
    with st.spinner("🔄 Loading MusicGen model... This may take a moment."):
        st.session_state['model'] = load_model()
        st.success("✅ Model loaded successfully!")

model = st.session_state['model']

st.markdown("""
<div class="glass-card">
    <h2 style="color: white; text-align: center; margin-bottom: 1.5rem;">🎯 Music Generation Studio</h2>
</div>
""", unsafe_allow_html=True)

st.markdown("""
<div class="glass-card prompt-examples">
    <h3 style="color: white; margin-bottom: 1rem;">💡 Example Prompts</h3>
    <p style="color: rgba(255, 255, 255, 0.7); margin-bottom: 1rem;">Click on any example to use it as your prompt!</p>
""", unsafe_allow_html=True)

example_prompts = [
    "Upbeat electronic dance music with synthesizers",
    "Relaxing jazz piano with soft drums",
    "Epic orchestral soundtrack with strings and brass",
    "Lo-fi hip hop beats with vinyl crackle",
    "Acoustic guitar ballad with emotional melody",
    "Energetic rock anthem with electric guitar",
    "Ambient atmospheric soundscape with pads",
    "Funky bass line with groovy drums",
    "Classical piano piece in minor key",
    "Tropical house with steel drums and marimbas"
]

cols = st.columns(3)
for i, prompt in enumerate(example_prompts):
    with cols[i % 3]:
        if st.button(f"🎵 {prompt}", key=f"example_{i}", help="Click to use this prompt"):
            st.session_state['prompt'] = prompt
            st.rerun()

col1, col2, col3 = st.columns([6,2,2])

with col1:
    prompt = st.text_input(
        "🎼 Enter your music prompt (in English):",
        value=st.session_state['prompt'],
        placeholder="e.g., Upbeat electronic dance music with synthesizers and drums"
    )
with col2:
    duration = st.slider("Duration (seconds)", min_value=10, max_value=60, value=st.session_state['duration'], step=1)
with col3:
    st.markdown("<br>", unsafe_allow_html=True)
    generate = st.button("🎵 Generate Music", type="primary", use_container_width=True)

if duration != st.session_state['duration']:
    st.session_state['duration'] = duration
    st.session_state['model'].set_generation_params(duration=duration)

if generate and prompt:
    st.markdown("""
    <div class="glass-card">
        <div style="text-align: center; color: white;">
            <div class="loading-spinner"></div>
            <h3 style="margin-top: 1rem;">🎵 Generating your music...</h3>
            <p style="color: rgba(255, 255, 255, 0.7);">This may take 30-60 seconds depending on your duration & system</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    start_time = time.time()
    
    try:
        with st.spinner("🎼 Creating your masterpiece..."):
            wav = model.generate([prompt], progress=True)
            audio = wav[0].cpu().numpy()

            if audio.ndim == 2 and audio.shape[0] == 1:
                audio = audio.flatten()
            elif audio.ndim == 2 and audio.shape[0] == 2:
                audio = audio.T
            elif audio.ndim == 2 and audio.shape[0] > 2:
                audio = audio[:2, :].T

            generation_time = time.time() - start_time
            
            st.session_state['audio'] = audio
            st.session_state['prompt'] = prompt
            st.session_state['generation_time'] = generation_time

            st.markdown("""
            <div class="success-message">
                🎉 Music generated successfully! Ready to play your creation.
            </div>
            """, unsafe_allow_html=True)
            
            st.rerun()
            
    except Exception as e:
        st.error(f"❌ Error generating music: {str(e)}")

if st.session_state['audio'] is not None:
    audio = st.session_state['audio']
    duration = audio.shape[0] / 32000
    
    st.markdown("""
    <div class="glass-card">
        <h2 style="color: white; text-align: center; margin-bottom: 1.5rem;">🎧 Your Generated Music</h2>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="glass-card">
        <div class="generation-stats">
            <div class="stat-card">
                <div class="stat-value">{:.1f}s</div>
                <div class="stat-label">Duration</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">32kHz</div>
                <div class="stat-label">Sample Rate</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{:.1f}s</div>
                <div class="stat-label">Gen Time</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{}</div>
                <div class="stat-label">Channels</div>
            </div>
        </div>
    </div>
    """.format(
        duration,
        st.session_state['generation_time'],
        "Stereo" if len(audio.shape) > 1 and audio.shape[1] == 2 else "Mono"
    ), unsafe_allow_html=True)

    st.markdown(f"""
    <div style="text-align: center; margin-bottom: 1rem;">
        <h3 style="color: white; margin-bottom: 0.5rem;">🎵 "{st.session_state['prompt']}"</h3>
        <p style="color: rgba(255, 255, 255, 0.7); font-style: italic;">Click play to listen to your creation</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.audio(audio, sample_rate=32000, format="audio/wav")
    st.markdown('</div>', unsafe_allow_html=True)

    import io
    audio_bytes = io.BytesIO()
    sf.write(audio_bytes, audio, 32000, format='WAV')
    audio_bytes.seek(0)
    
    filename = f"{st.session_state['prompt'].replace(' ', '_')[:50]}.wav"
    
    st.markdown("""
    <div style="margin-bottom: 1rem;">
        <h3 style="color: white; margin-bottom: 0.5rem;">💾 Download Your Music</h3>
        <p style="color: rgba(255, 255, 255, 0.7);">Save your generated track as a high-quality WAV file</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.download_button(
        label="⬇️ Download Music (.wav)",
        data=audio_bytes.getvalue(),
        file_name=filename,
        mime="audio/wav",
        use_container_width=True
    )
    
    st.markdown('</div>', unsafe_allow_html=True)

st.markdown("""
<div class="glass-card" style="text-align: center; margin-top: 2rem;">
    <p style="color: rgba(255, 255, 255, 0.6); margin-bottom: 0.5rem;">
        9.5AI | MusicGen Studio
    </p>
    <p style="color: rgba(255, 255, 255, 0.4); font-size: 0.9rem;">
        Create, Listen, Download • Professional AI Music Generation
    </p>
</div>
""", unsafe_allow_html=True)

st.markdown('</div>', unsafe_allow_html=True)