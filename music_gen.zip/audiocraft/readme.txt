1.Thông tin sản phẩm: sản phẩm tạo ra bản nhạc dựa trên đoạn prompt gồm cảm xúc và nhạc cụ
2.Sử dụng model Music Gen của Meta AI(hiện đang dùng model "medium", có thể dùng "large"/"small")
3.Input: nhập vào đoạn text mô tả chứa cảm xúc và loại nhạc cụ muốn dùng để tạo ra bản nhạc -> chọn duration(thời gian của bản nhạc 10s-60s)
4.Output: bản nhạc được gen ra bởi AI
5.Chạy sản phẩm: chạy file core.py -> thao tác nhập text/chọn duration -> gen nhạc -> đợi kết quả, nghe thử nhạc và lưu nhạc
6.Chỉ thực hiện thao tác bằng chuột